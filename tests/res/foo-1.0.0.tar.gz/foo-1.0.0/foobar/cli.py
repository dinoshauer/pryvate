def main():
    print 'hi from foobar!'
