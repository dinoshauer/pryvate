from setuptools import find_packages, setup

setup(
    name='foo',
    description='Foo.',
    packages=find_packages(),
    version='1.0.0',
    install_requires=[
    ],
    entry_points={
        'console_scripts': [
            'foo-bar = foobar.cli:main',
        ]
    },
    classifiers=[
    ],
)
