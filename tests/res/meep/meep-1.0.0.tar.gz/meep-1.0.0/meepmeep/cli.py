def main():
    print 'hi!'
