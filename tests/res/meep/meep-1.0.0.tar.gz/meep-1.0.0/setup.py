"""Installation instructions for the Semantria processes."""

from setuptools import find_packages, setup

setup(
    name='meep',
    description='Meep.',
    packages=find_packages(),
    version='1.0.0',
    install_requires=[
    ],
    entry_points={
        'console_scripts': [
            'meep-meep = meepmeep.cli:main',
        ]
    },
    classifiers=[
    ],
)
